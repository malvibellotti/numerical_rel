/*@@
  @header   UPPERMET_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef UPPERMET_GUTS

#include "DETG_undefine.h"
