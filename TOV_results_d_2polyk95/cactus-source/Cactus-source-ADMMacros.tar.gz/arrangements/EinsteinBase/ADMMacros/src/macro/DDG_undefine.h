/*@@
  @header   DDG_undefine.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/ 

#undef DDG_GUTS

#include "DXXDG_undefine.h"
#include "DXYDG_undefine.h"
#include "DXZDG_undefine.h"
#include "DYYDG_undefine.h"
#include "DYZDG_undefine.h"
#include "DZZDG_undefine.h"

