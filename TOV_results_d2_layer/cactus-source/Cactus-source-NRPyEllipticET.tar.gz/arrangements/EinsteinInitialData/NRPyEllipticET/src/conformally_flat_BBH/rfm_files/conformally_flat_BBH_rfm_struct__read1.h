CCTK_ATTRIBUTE_UNUSED const REAL f1_of_xx1 = rfmstruct->f1_of_xx1[i1];
CCTK_ATTRIBUTE_UNUSED const REAL f1_of_xx1__D1 = rfmstruct->f1_of_xx1__D1[i1];
CCTK_ATTRIBUTE_UNUSED const REAL f1_of_xx1__DD11 = rfmstruct->f1_of_xx1__DD11[i1];
