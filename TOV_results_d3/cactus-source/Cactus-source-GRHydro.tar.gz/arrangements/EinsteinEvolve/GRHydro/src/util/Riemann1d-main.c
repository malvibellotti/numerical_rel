void CCTK_FNAME(Riemann1d)(void);

int main(void)
{
  CCTK_FNAME(Riemann1d)();
  return 0;
}
