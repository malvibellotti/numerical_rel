#ifndef WVU_VI_GRMHD_REDUCTIONS_C
#define WVU_VI_GRMHD_REDUCTIONS_C

#include "cctk.h"
#include "cctk_Parameters.h"
#include "cctk_Arguments.h"
#include "util_Table.h"
#include <assert.h>
#include <math.h>
#include <stdlib.h>

/* ADD TO THIS LIST IF YOU HAVE NEW INTEGRAND */
static inline int VI_GRMHD_number_of_reductions(int which_integral) {
  DECLARE_CCTK_PARAMETERS;
  if(CCTK_EQUALS(Integration_quantity_keyword[which_integral],"usepreviousintegrands")) return volintegral_usepreviousintegrands_num_integrands[which_integral];
  if(CCTK_EQUALS(Integration_quantity_keyword[which_integral],"centerofmass")) return 4;
  if(CCTK_EQUALS(Integration_quantity_keyword[which_integral],"restmass")) return 1;
  if(CCTK_EQUALS(Integration_quantity_keyword[which_integral],"one")) return 1;

  CCTK_VERROR("You forgot to specify the number of reductions for Integration_quantity_keyword=%s!",
              Integration_quantity_keyword[which_integral]);
  return -1000;
}
#endif
