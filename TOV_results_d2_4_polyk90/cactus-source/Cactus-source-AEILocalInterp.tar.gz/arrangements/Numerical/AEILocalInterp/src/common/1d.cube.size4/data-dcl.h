fp data_m1;
fp data_0;
fp data_p1;
fp data_p2;
