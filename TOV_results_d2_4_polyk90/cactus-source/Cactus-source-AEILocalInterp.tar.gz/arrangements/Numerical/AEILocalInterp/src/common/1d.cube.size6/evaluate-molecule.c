    coeffs->coeff_m2*data->data_m2
  + coeffs->coeff_m1*data->data_m1
  + coeffs->coeff_0*data->data_0
  + coeffs->coeff_p1*data->data_p1
  + coeffs->coeff_p2*data->data_p2
  + coeffs->coeff_p3*data->data_p3;
