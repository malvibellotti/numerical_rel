    coeffs->coeff_0*data->data_0
  + coeffs->coeff_p1*data->data_p1;
