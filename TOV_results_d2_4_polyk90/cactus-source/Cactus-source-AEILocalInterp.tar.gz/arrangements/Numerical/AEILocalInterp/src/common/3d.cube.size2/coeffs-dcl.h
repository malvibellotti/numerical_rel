fp coeff_0_0_0;
fp coeff_p1_0_0;
fp coeff_0_p1_0;
fp coeff_p1_p1_0;
fp coeff_0_0_p1;
fp coeff_p1_0_p1;
fp coeff_0_p1_p1;
fp coeff_p1_p1_p1;
