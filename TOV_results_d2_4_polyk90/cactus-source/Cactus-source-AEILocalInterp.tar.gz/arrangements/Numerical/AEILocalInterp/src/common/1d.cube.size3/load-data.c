data->data_m1 = DATA(-1);
data->data_0 = DATA(0);
data->data_p1 = DATA(1);
