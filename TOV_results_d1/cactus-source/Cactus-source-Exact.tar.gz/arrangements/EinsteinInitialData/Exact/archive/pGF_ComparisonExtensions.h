  int do_comparison;
