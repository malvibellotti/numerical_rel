typedef struct __rfmstruct__ {
} rfm_struct;
