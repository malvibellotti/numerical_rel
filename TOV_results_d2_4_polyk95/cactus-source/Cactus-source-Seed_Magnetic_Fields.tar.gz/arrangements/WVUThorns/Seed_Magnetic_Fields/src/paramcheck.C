#include "cctk.h"
#include "cctk_Parameters.h"
#include <cctk_Arguments.h>

extern "C" 
void Seed_Magnetic_Fields_paramcheck(CCTK_ARGUMENTS) {
   DECLARE_CCTK_PARAMETERS;

  if( CCTK_EQUALS(Afield_type, "Pressure_prescription") || CCTK_EQUALS(Afield_type, "Density_prescription") )
    CCTK_WARN(CCTK_WARN_COMPLAIN, "Warning: the Afield_type options 'Pressure_prescription'\n"
              "and 'Density_prescription' are deprecated and will be removed\n"
              "in the next release. Please switch to using\n"
              "'TOV_pressure_prescription' and 'TOV_density_prescription'.");
}
