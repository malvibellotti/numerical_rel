#include "boundaries_impl.hxx"

namespace CarpetX {

template void BoundaryCondition::apply_on_face<NEG, INT, POS>() const;

} // namespace CarpetX
