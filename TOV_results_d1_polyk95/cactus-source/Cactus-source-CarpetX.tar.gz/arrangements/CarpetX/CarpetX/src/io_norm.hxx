#ifndef CARPETX_CARPETX_IO_NORM_HXX
#define CARPETX_CARPETX_IO_NORM_HXX

#include <cctk.h>

namespace CarpetX {

void OutputNorms(const cGH *restrict cctkGH);

}

#endif // #define CARPETX_CARPETX_IO_NORM_HXX
